//
//  BookListView.swift
//  BookManagerMDI1105
//
//  Created by Alex Arthur on 12/11/25.
//

import SwiftUI
import SwiftData

struct BookListView: View {
    @Environment(\.modelContext) var modelContext
    
    // REPLACE @Binding with @Query
    @Query var books: [Book]
    
    @State private var isShowingFilterSheet = false
    @State private var isShowingAddSheet = false // Add this
    @State private var filterGenre: Genre? = nil
    @State private var filterShowFavoritesOnly = false
    
    @AppStorage("settingShowBookCovers") private var showBookCovers = true
    @AppStorage("settingSortAlphabetical") private var sortAlphabetical = false

    var filteredAndSortedBooks: [Book] {
        var result = books.filter { book in
            if filterShowFavoritesOnly && !book.isFavorite { return false }
            if let selected = filterGenre, book.genre != selected { return false }
            return true
        }
        
        if sortAlphabetical {
            result.sort { $0.title < $1.title }
        }
        return result
    }
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(filteredAndSortedBooks) { book in
                    // Navigate to the correct BookDetailView
                    NavigationLink(destination: BookDetailView(book: book)) {
                        HStack(spacing: 12) {
                            if showBookCovers {
                                // Logic for handling both data and asset images
                                Group {
                                    if let data = book.imageData, let uiImage = UIImage(data: data) {
                                        Image(uiImage: uiImage).resizable()
                                    } else {
                                        Image(book.coverImage.isEmpty ? "book.closed.fill" : book.coverImage).resizable()
                                    }
                                }
                                .scaledToFill()
                                .frame(width: 50, height: 75)
                                .cornerRadius(8)
                                .clipped()
                            }
                            
                            VStack(alignment: .leading) {
                                Text(book.title).font(.headline)
                                Text(book.author).font(.subheadline).foregroundColor(.secondary)
                            }
                            Spacer()
                            FavoriteToggleWrapper(book: book)
                        }
                    }
                }
                .onDelete(perform: deleteBooks)
            }
            .navigationTitle("My Library")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    HStack {
                        Button { isShowingFilterSheet = true } label: {
                            Label("Filter", systemImage: "line.3.horizontal.decrease.circle")
                        }
                        // Add Button
                        Button { isShowingAddSheet = true } label: {
                            Label("Add", systemImage: "plus")
                        }
                    }
                }
            }
            .sheet(isPresented: $isShowingFilterSheet) {
                FilterView(selectedGenre: $filterGenre, showOnlyFavorites: $filterShowFavoritesOnly)
            }
            .sheet(isPresented: $isShowingAddSheet) {
                BookEntryView() // Opens the entry view
            }
        }
    }
    
    private func deleteBooks(offsets: IndexSet) {
        withAnimation {
            for index in offsets {
                modelContext.delete(filteredAndSortedBooks[index])
            }
        }
    }
}

// Helper needed because standard Binding doesn't work easily with @Query arrays in List
struct FavoriteToggleWrapper: View {
    @Bindable var book: Book
    var body: some View {
        FavoriteToggle(isFavorite: $book.isFavorite)
    }
}
