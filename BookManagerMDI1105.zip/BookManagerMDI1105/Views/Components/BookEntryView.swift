//
//  BookEntryView.swift
//  BookManagerMDI1105
//
//  Created by Alex Arthur on 12/13/25.
//

import SwiftUI
import SwiftData // <--- THIS WAS MISSING
import PhotosUI

struct BookEntryView: View {
    @Environment(\.modelContext) var modelContext
    @Environment(\.dismiss) var dismiss
    
    var bookToEdit: Book?
    
    @State private var title = ""
    @State private var author = ""
    @State private var genre: Genre = .fantasy
    @State private var status: ReadingStatus = .toRead
    @State private var rating = 3
    @State private var isFavorite = false
    
    // Image selection
    @State private var selectedItem: PhotosPickerItem?
    @State private var selectedImageData: Data?
    
    var isEditing: Bool {
        bookToEdit != nil
    }
    
    var body: some View {
        NavigationView {
             Form {
                // ... (Your existing form fields)
                Section(header: Text("Book Details")) {
                    TextField("Title", text: $title)
                    TextField("Author", text: $author)
                }
                // ... (Add other sections from previous instructions if missing)
             }
             .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        saveBook()
                        dismiss()
                    }
                }
             }
        }
    }
    
    func saveBook() {
        if let book = bookToEdit {
            // Edit existing
            book.title = title
            book.author = author
            book.genre = genre
            book.status = status
            book.rating = rating
            book.isFavorite = isFavorite
            book.imageData = selectedImageData
        } else {
            // Create new
            let newBook = Book(
                title: title,
                author: author,
                imageData: selectedImageData, // Uses the new property
                isFavorite: isFavorite,
                genre: genre,
                rating: rating,
                status: status
            )
            modelContext.insert(newBook)
        }
    }
}
