//
//  BookCard.swift
//  BookManagerMDI1105
//
//  Created by Alex Arthur on 12/6/25.
//

import SwiftUI

struct BookCard: View {
    
    // Note: Since we changed Book to a class, we use Bindable in wrappers,
    // but for simple display, we can just pass the object.
    // If you need to edit inside the card, use @Bindable.
    let book: Book
    
    var body: some View {
        VStack{
            Text(book.title)
            Spacer()
            Text (book.author)
        }
        // Logic to support both new Data images and old Asset images
        .background(
            Group {
                if let data = book.imageData, let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage).resizable()
                } else {
                    Image(book.coverImage.isEmpty ? "book.closed" : book.coverImage).resizable()
                }
            }
        )
        .aspectRatio(1, contentMode: .fit)
        .cornerRadius(12)
        // FIXED PARENTHESIS HERE:
        .shadow(color: .black.opacity(0.5), radius: 10, x: 0, y: 5)
    }
}
