//
//  FilterView.swift
//  BookManagerMDI1105
//
//  Created by Alex Arthur on 12/11/25.
//

import SwiftUI

struct FilterView: View {
    //dismisses the sheet programmatically
    @Environment(\.dismiss) var dismiss
    
    //bindings connect to state variables in BookListView.
    //change them here for the main list update
    @Binding var selectedGenre: Genre?
    @Binding var showOnlyFavorites: Bool
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Filters")) {
                    //favorites toggle
                    Toggle(isOn: $showOnlyFavorites) {
                        Label("Favorites Only", systemImage: "heart.fill")
                    }
                    
                    //genre picker
                    Picker(selection: $selectedGenre, label: Label("Genre", systemImage: "book.closed")) {
                        Text("All Genres").tag(Genre?.none) //option to select nothing
                        // FIX: Added id: \.self for Identifiable error
                        ForEach(Genre.allCases, id: \.self) { genre in
                            Text(genre.rawValue).tag(genre as Genre?)
                        }
                    }
                }
                
                Section {
                    //extra credit
                    Button(role: .destructive) {
                        //filter default reset
                        selectedGenre = nil
                        showOnlyFavorites = false
                        dismiss()
                    } label: {
                        Label("Clear All Filters", systemImage: "xmark.circle")
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                    // FIX: Apply .plain style to remove the old-style rounded frame
                    .buttonStyle(.plain)
                }
            }
            .navigationTitle("Filter Books")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Close") {
                       dismiss()
                    }
                }
            }
        }
    }
}
