//
//  FavoritesView.swift
//  BookManagerMDI1105
//
//  Created by Alex Arthur on 12/6/25.
//

import SwiftUI

struct FavoritesView: View {
    // The view needs access to the full list of books to determine which ones are favorites.
    //ensures if a book changes, this view updates
    @Binding var books: [Book]
    
    //two column grid layout
    let gridLayout = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]
    
    //fixed computed property syntax
    //filters the main array down to just favorites
    var favoriteBooks: [Book] {
        books.filter { $0.isFavorite }
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                //for performance assist with the layout above
                LazyVGrid(columns: gridLayout, spacing: 16) {
                    ForEach(favoriteBooks) { book in
                        //this destination would be a BookDetailView.
                        //just leads to text for now
                        NavigationLink(destination: Text("Details for \(book.title)")) {
                            SquareCardView(book: book)
                        }
                        //reset button style so the whole card doesnt flash
                        .buttonStyle(.plain)
                    }
                }
                .padding()
            }
            .navigationTitle("Favorite Books")
            //subtle background color
            .background(Color(.systemGroupedBackground))
        }
    }
}
