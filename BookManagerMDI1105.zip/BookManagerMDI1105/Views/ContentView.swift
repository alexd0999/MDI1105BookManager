//
//  ContentView.swift
//  BookManagerMDI1105
//
//  Created by Alex Arthur on 11/25/25.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    // 1. Get access to the database context
    @Environment(\.modelContext) private var modelContext
    // 2. Use a flag to ensure we only load data once
    @AppStorage("hasLoadedSampleData") private var hasLoadedSampleData = false
    
    @AppStorage("SETTING_THEME") private var selectedTheme: Theme = .system
    
    var body: some View {
        //MAIN VIEW TAB INTEGRATION
        TabView {
            BookListView()
                .tabItem {
                    Label("Books", systemImage: "book.fill")
                }
            
            Text("Favorites Placeholder")
                .tabItem {
                    Label("Favorites", systemImage: "heart.fill")
                }
            
            Settings()
                .tabItem {
                    Label("Settings", systemImage: "gearshape")
                }
        }
        .modelContainer(for: Book.self)
        // 3. Load data only if the flag is false (first launch)
        .onAppear {
            if !hasLoadedSampleData {
                loadSampleData()
                hasLoadedSampleData = true
            }
        }
    }
    
    // 4. Function to insert the sample books
    private func loadSampleData() {
        print("Inserting sample data on first launch.")
        for book in Book.sampleData {
            modelContext.insert(book)
        }
    }
}
