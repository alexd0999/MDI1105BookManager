//
//  BookManagerMDI1105App.swift
//  BookManagerMDI1105
//
//  Created by Alex Arthur on 11/25/25.
//

import SwiftUI

@main
struct BookManagerMDI1105App: App {

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
